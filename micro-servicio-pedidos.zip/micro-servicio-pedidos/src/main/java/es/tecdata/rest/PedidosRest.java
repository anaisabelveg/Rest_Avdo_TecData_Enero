package es.tecdata.rest;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.tecdata.models.Pedido;
import es.tecdata.services.IPedidoService;

@RestController
public class PedidosRest {
	
	//@Autowired
	//@Qualifier(value = "serviceFeign")
	
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}

}
