package es.tecdata.rest;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.tecdata.models.Pedido;
import es.tecdata.models.Producto;
import es.tecdata.services.IPedidoService;

@RestController
public class PedidosRest {
	
	//@Autowired
	//@Qualifier(value = "serviceFeign")
	
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto(id, "Producto vacio", 0);
		return new Pedido(producto, cantidad);
	}

}
