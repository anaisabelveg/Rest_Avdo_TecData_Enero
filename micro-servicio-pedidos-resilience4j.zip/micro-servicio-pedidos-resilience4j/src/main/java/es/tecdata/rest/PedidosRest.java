package es.tecdata.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.tecdata.models.Pedido;
import es.tecdata.models.Producto;
import es.tecdata.services.IPedidoService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class PedidosRest {
	
	//@Autowired
	//@Qualifier(value = "serviceFeign")
	
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError")
	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto(id, "Producto vacio", 0);
		return new Pedido(producto, cantidad);
	}

}
