insert into USUARIOS (username, password, nombre, apellido) values ('juan', '1234', 'Juan', 'Lopez');
insert into USUARIOS (username, password, nombre, apellido) values ('admin', '9876', 'Pedro', 'Arias');

insert into ROLES (nombre) values ('ROLE_USER');
insert into ROLES (nombre) values ('ROLE_ADMIN');

insert into USUARIOS_ROLES (usuario_id, role_id) values (1, 1);
insert into USUARIOS_ROLES (usuario_id, role_id) values (2, 1);
insert into USUARIOS_ROLES (usuario_id, role_id) values (2, 2);