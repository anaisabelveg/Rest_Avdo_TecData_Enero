package es.tecdata.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() throws ZuulException {

		// Tomar el tiempo final
		long tiempoFinal = System.currentTimeMillis();
		
		// Recuperar el tiempo inicial del atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		long tiempoInicial = (long) ctx.getRequest().getAttribute("tiempoInicio");
		
		// Mostrar la diferencia de tiempos
		System.out.println("***********************************");
		System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicial) + " mseg.");
		System.out.println("***********************************");
		
		return null;
	}

	@Override
	public String filterType() {
		return "post";
	}

	@Override
	public int filterOrder() {
		return 1;
	}

}
