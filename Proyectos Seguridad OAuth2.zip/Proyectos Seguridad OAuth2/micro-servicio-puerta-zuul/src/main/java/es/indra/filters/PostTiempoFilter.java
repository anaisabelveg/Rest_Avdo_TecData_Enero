package es.indra.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Si devuelve true se ejecuta el metodo run()
		// Si devuelve false lo ignora
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Lo que quiero ejecutar en el filtro va aqui
		// Tomar el tiempo final
		Long tiempoFinal = System.currentTimeMillis();
		
		// Recuperamos el tiempo de inicio
		RequestContext ctx = RequestContext.getCurrentContext();
		Long tiempoInicio =  (Long) ctx.getRequest().getAttribute("tiempoInicio");
		
		// Mostrar la diferencia de tiempos en consola
		System.out.println("**************************************");
		System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio + " mseg."));
		System.out.println("**************************************");
		
		return null;
	}

	@Override
	public String filterType() {
		// Uno de estos valores "pre", "post", "route"
		// Son palabras clave
		return "post";
	}

	@Override
	public int filterOrder() {
		// Orden de ejecuccion en el caso de tener varios filtros
		return 1;
	}

}
