package es.indra.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PreTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Si devuelve true se ejecuta el metodo run()
		// Si devuelve false lo ignora
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Lo que quiero ejecutar en el filtro va aqui
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		// Lo guardo como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.getRequest().setAttribute("tiempoInicio", tiempoInicio);
		
		return null;
	}

	@Override
	public String filterType() {
		// Uno de estos valores "pre", "post", "route"
		// Son palabras clave
		return "pre";
	}

	@Override
	public int filterOrder() {
		// Orden de ejecuccion en el caso de tener varios filtros
		return 1;
	}

}
