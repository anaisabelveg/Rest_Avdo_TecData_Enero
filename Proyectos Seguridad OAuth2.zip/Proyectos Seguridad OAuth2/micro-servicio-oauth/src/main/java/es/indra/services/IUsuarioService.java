package es.indra.services;

import es.indra.models.Usuario;

public interface IUsuarioService {
	
	public Usuario findByUsername(String username);

}
