package es.tecdata.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.tecdata.business.ItfzProductosBS;
import es.tecdata.models.Carrito;

@Controller
@RequestMapping("/")
public class ComprarController {
	
	@Autowired
	private ItfzProductosBS productosBS;
	
	@RequestMapping(method = RequestMethod.POST, value = "comprar")
	public String addPedido(long id, int cantidad, HttpServletRequest request) {
		
		String usuario = buscarCookie(request);
		
		// Si no encuentro la cookie con el nombre de usuario mando logarse
		if (usuario == null) return "formLogin";
		
		// Si esta logado:
		// agregar el pedido con el id y la cantidad
		// guardar el carrito como atributo de peticion
		productosBS.agregar(id, cantidad, usuario);
		Carrito carrito = productosBS.consultar(usuario);
		request.setAttribute("carrito", carrito);
		return "mostrarCarrito";
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "eliminar")
	public String eliminarPedido(long id, HttpServletRequest request) {
		
		String usuario = buscarCookie(request);
		
		productosBS.eliminar(id, usuario);
		Carrito carrito = productosBS.consultar(usuario);
		request.setAttribute("carrito", carrito);
		return "mostrarCarrito";
	}
	
	private String buscarCookie(HttpServletRequest request) {
		String usuario = null;
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ("nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
			}
		}
		return usuario;
	}

}
