package es.tecdata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.tecdata.models.Producto;
import es.tecdata.persistence.ProductosDAO;

@SpringBootApplication
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Insertar 5 registros en la BBDD
		dao.insert(new Producto(1L, "Pantalla", 149.50));
		dao.insert(new Producto(2L, "Teclado", 37.95));
		dao.insert(new Producto(3L, "Raton", 25.50));
		dao.insert(new Producto(4L, "Impresora", 89.75));
		dao.insert(new Producto(5L, "Scanner", 215.90));
		
		// Mostrar todos los productos en consola
		dao.findAll().stream()
			.forEach(System.out::println);
		System.out.println("-------------------");
		
		// Buscar un producto
		System.out.println(dao.findById(4L));
	}

}
