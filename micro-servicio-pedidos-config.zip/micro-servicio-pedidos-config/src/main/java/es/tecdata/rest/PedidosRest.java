package es.tecdata.rest;

import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.tecdata.models.Pedido;
import es.tecdata.models.Producto;
import es.tecdata.services.IPedidoService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;

@RestController
public class PedidosRest {
	
	//@Autowired
	//@Qualifier(value = "serviceFeign")
	
	@Resource(name = "serviceFeign")
	private IPedidoService service;
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError")
	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError2")
	@TimeLimiter(name = "pedidos")
	// http://localhost:8002/crear2/3/cantidad/100
	@GetMapping("/crear2/{id}/cantidad/{cantidad}")
	public CompletableFuture<Pedido> crearPedido2(@PathVariable Long id, @PathVariable int cantidad) {
		return  CompletableFuture.supplyAsync( () -> service.crearPedido(id, cantidad) );
	}
		
	
	public CompletableFuture<Pedido> manejarError2(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto(id, "Producto lento", 0);
		return   CompletableFuture.supplyAsync( () ->  new Pedido(producto, cantidad));
	}
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto(id, "Producto vacio", 0);
		return new Pedido(producto, cantidad);
	}

}
