package es.tecdata.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.tecdata.clients.PedidosClienteFeign;
import es.tecdata.models.Carrito;
import es.tecdata.models.Pedido;
import es.tecdata.persistence.CarritoDAO;

@Service
public class CarritoServiceFeign implements ICarritoService{
	
	@Autowired
	private CarritoDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito agregarPedido(Long id, int cantidad, String usuario) {
		Pedido pedido = clienteFeign.crearPedido(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importe = carrito.getImporte() + (pedido.getProducto().getPrecio() * cantidad);
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		Pedido encontrado = null;
		for (Pedido pedido : contenido) {
			if (pedido.getProducto().getID() == id) {
				encontrado = pedido;
				break;
			}
		}
		
		contenido.remove(encontrado);
		double importe = carrito.getImporte() - 
				(encontrado.getProducto().getPrecio() * encontrado.getCantidad());
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

}
